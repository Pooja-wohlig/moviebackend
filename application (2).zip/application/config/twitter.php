<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['twitter_consumer_token']		= 'mhpazXsA8opYSwjg7tx9fQjkH';
$config['twitter_consumer_secret']		= 'fR7eXCJJFjgyFXY2muGC8OGkCBOeQ6GQGgqqwNmg2ZN98ePmaw';
$config['twitter_access_token']			= '121427044-dmXIDD4o4VfykmH1DusjDfsDY11N1x0UsfwE6DFZ'; // Optional
$config['twitter_access_secret']		= 'd6zZmQhKoTJ3DPzmVmM2g7571vPkZ6j8kyVqrR5nMqLfo'; // Optional

/* End of file twitter.php */
/* Location: ./application/config/twitter.php */